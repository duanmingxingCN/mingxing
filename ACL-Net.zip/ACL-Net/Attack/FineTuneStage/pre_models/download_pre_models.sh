wget -P ./densenet121 https://download.pytorch.org/models/densenet121-a639ec97.pth
wget -P ./resnext101_32x4d http://data.lip6.fr/cadene/pretrainedmodels/resnext101_32x4d-29e315fa.pth
wget -P ./resnext101_64x4d http://data.lip6.fr/cadene/pretrainedmodels/resnext101_64x4d-e77a0586.pth
