from .resnet import *
# from .resnet_cifar import *
from .resnet_cifar2 import *
