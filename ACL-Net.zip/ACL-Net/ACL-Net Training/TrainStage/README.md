# ACL-NET
Code for ACL

# Usage

##  Run ACL contrastive learning methods
1. Enter to Plain folder
```
cd ACL-Net
```
2. Run contrastive learning baseline (use cifar100 [cifar10, tinyImagenet] for example)
```
python main.py --dataset cifar100 --batch-size 128 --gpu 0 --trial 1 
python eval.py --dataset cifar100 --batch-size 128 --gpu 0 --trial 1 
```
3. Run contrastive learning with adversarial training (use cifar100 [cifar10, tinyImagenet] for example)
```
python main.py --dataset cifar100 --batch-size 128 --gpu 0 --trial 1 --adv --bn_adv_momentum 0.01 --eps 0.03  --is_dis=True
python eval.py --dataset cifar100 --batch-size 128 --gpu 0 --trial 1 --adv --bn_adv_momentum 0.01 --eps 0.03  
```

