# GDAS searched CNN architecture
This folder contains a slightly modified version of the  [GDAS](https://github.com/D-X-Y/GDAS) project code (Copyright to [Xuanyi Dong](https://github.com/D-X-Y)).

I discard the architecture searching process but keep the network definition scripts unchanged, since only the searched architecture is relevant to our subspace based black box attack project.
